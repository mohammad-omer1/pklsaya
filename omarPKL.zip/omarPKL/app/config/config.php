<?php 
define('DB_HOST', 'Localhost');
define('DB_USER', 'admin');
define('DB_PASS', 'saboor123');
define('DB_NAME', 'thesis');